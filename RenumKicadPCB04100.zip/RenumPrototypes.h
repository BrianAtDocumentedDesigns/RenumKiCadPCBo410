/*
 * RenumProtoTypes.h
 *
 *  Created on: Mar. 30, 2019
 *      Author: BrianP
 */

#ifndef RENUMPROTOTYPES_H_
#define RENUMPROTOTYPES_H_

#include    <iostream>
#include    <fstream>
#include    <sstream>
#include    <bitset>
#include    <string>
#include    <math.h>

#ifndef     _MSC_VER
#include    <unistd.h>
#else
#include	<io.h>
#endif

#include    <stdbool.h>
#include    <vector>        //Vector
#include    <algorithm>     //Sort
#include    "RenumStructures.h"
//
// Function prototypes
//

void        SaveKiCadFile( struct KiCadFile &kicadfile );
void        PullLineIntoString( std::string& dest, size_t& newline, const std::string& source );
void        FlattenSchematic( void );
void        UpdateProjectRefDes( bool messages );
void        UpdatePCBRefDes( struct KiCadFile &PCBFile, bool messages );
void        UpdateSchematicFileRefDes( struct KiCadFile &Schematic, bool messages  );
void        UpdateNetlistRefDes( struct KiCadFile &Schematic, bool messages );

int         FindNewRefDes( std::vector <RefDesChange> &ChangeArray, std::string& NewRefDes, const std::string& OldRefDes, bool& unannotated );    // Find it in the change array
int         LoadPCBFile( struct KiCadFile &Schematic );
void        GetParenDelimitedField( std::string& outfield, const std::string& inbuf, const size_t& fieldstart );

bool        GetXY( const std::string &buffer, const char *field, 
                        size_t &startcoord, size_t &endcoord, double &xcoord, double &ycoord );
bool        GetXY( const std::string &buffer, const char *field, 
                        size_t &startcoord, size_t &endcoord, std::string &xcoord, std::string &ycoord );
bool        GetXYandAngle( const std::string &buffer, const char *field, 
                        size_t &startcoord, size_t &endcoord, double &xcoord, double &ycoord, double &angle );
bool        GetXYandAngle( const std::string &buffer, const char *field, 
                        size_t &startcoord, size_t &endcoord, std::string &xcoord, std::string &ycoord, std::string &angle );

void        RenumKiCadPCB(void);

std::string FloatFormat( double anum, int decimal );
void        LogLineItUp(  std::string text, int tab  );
void        WriteLogFile(void);
void        WriteChangeArray( void );
void        LoadParameterFile( void);
void        WriteParameterFile( void);
void        WriteStringtoFile(FileName filename, std::string& buffer);
void        LoadFileIntoString(std::string& outbuffer, FileName &filename);
void        TrimString( std::string& input );
int         LoadModuleArray( std::string &PCBBuffer );

void        PCBSortSide(PCBSide Side, unsigned int& MaxRefDes, std::string& MaxRefDesName);
int         MakeChangeArray( void );
void        LogChangeArray( char * message );

void        LocateRefDes(std::string& Buffer, size_t& start, size_t& end);

//
// Use these to make messages a bit easier
//

void    ShowError( const char *message, int arg1);

void    FatalError( const char *message );
void    FatalError( const char *message, std::string arg1 );

void    ShowMessage( const char *message );
void    ShowMessage( const char *message, int arg1 );
void    ShowMessage( const char *message, std::string &arg1 );
void    ShowMessage( const char *message, std::string &arg1, std::string &arg2 );

void    ShowWarning( const char *message, int arg1 );
void    ShowWarning( const char *message, std::string& arg1  );
void    ShowWarning( const char *message, std::string& arg1, std::string& arg2 );

wxSize  AdjustItemSize(int x, int y);

#endif /* RENUMPROTOTYPES_H_ */
