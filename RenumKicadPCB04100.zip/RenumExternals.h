/*
 * RenumExternals.h
 *
 *  Created on: Apr. 3, 2019
 *      Author: BrianP
 */

#ifndef RENUMEXTERNALS_H_
#define RENUMEXTERNALS_H_

#include                "RenumStructures.h"
#include                "RenumKicadPCBClasses.h"

extern  bool            G_SortYFirst, G_DescendingFirst, G_DescendingSecond;
extern  bool            G_SortOnModules;      //Sort on modules/ref des
extern  bool            G_RemoveFrontPrefix;
extern  bool            G_RemoveBackPrefix;
extern  bool            G_WriteLogFile;
extern  bool            G_WriteChangeFile;

extern  int             G_Errcount;           //The error count
extern  int             G_SortCode;           //The Front sort code (left to right, etc.)
extern  unsigned int    G_FrontStartRefDes;     //The starting Front ref des;;
extern  unsigned int    G_BackStartRefDes;  //The starting Back ref des
extern  int             G_Modules;
extern  int             G_DirectionsArray[];
extern  int             G_BackDirectionsArray[];

extern  double          G_SortGrid;           //The sort grid

extern  struct          KiCadFile   G_netlist;
extern  struct          KiCadFile   G_PCBInputFile;

extern  std::string     G_FrontLayerName;
extern  std::string     G_FrontPrefix;        //The Front Prefix std::string
extern  std::string     G_BackPrefix;        //The Back Prefix std::string
extern  std::string     G_LogFile;
extern  FileName        G_ProjectName;

extern  const std::string ParameterList[];

extern  std::vector     <RefDesChange> G_ChangeArray;
extern  std::vector     <KiCadFile> G_AllSchematics;
extern  std::vector     <PCBModule> G_FrontModules;
extern  std::vector     <PCBModule> G_BackModules;
extern  std::vector     <RefDesTypeStruct> G_RefDesTypes;
extern  std::vector     <ModuleTextField> G_AllTextFields;

extern    RenumKicadPCB *G_RenumMenu;
extern    AboutDialog   *G_AboutDialog;
extern    ReadMeDialog  *G_ReadMeDialog;

extern   wxSize         G_MainDialogSize;   //The size of the Main Dialog

#endif /* RENUMEXTERNALS_H_ */
