#pragma once
#ifndef FILENAME_H_
#define FILENAME_H_

class FileName
{
public:
    std::string Directory;
    std::string Name;
    std::string Extension;

    FileName& operator=(std::string infile)
    {
        size_t  whereisdir = infile.rfind(SLASHCHR);
        size_t  whereisext = infile.rfind('.');

        if (NPOS != whereisdir)
            Directory = infile.substr(0, whereisdir + 1);    //Get the directory
        else
            Directory.clear();

        Name = infile.substr((NPOS == whereisdir ? 0 : whereisdir + 1), whereisext - whereisdir - 1);
        if (NPOS != whereisext)
            Extension = infile.substr(whereisext + 1); //Get the extension
        else
            Extension.clear();
        return *this;
    }

    std::string    FullName()
    {
        return(Directory + Name + '.' + Extension);
    }
private:
};

#endif
